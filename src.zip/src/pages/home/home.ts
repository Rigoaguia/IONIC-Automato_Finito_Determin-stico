import { Component, Input, Output, EventEmitter } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html',

})

export class HomePage {

  public cadeia: string;
  public estadoAtualSelect: number;
  public estadoDestinoSelect: number;
  public alfabetoSelectItem: string;
  public alfabetoSelect: string[];
  public items: Array<String>;
  public itemsTrasicao: Array<String>;
  public estadoinicialInf: string = "";
  public estadofinalInf: string = "";

  // components
  public NomeEstadoIn: string;
  public AlfabetoIn: string;
  public EstadoInicialIn: boolean;
  public EstadoFinalIn: boolean;
  //
  public estado: EstadoAFD;
  public estadoArray: Array<EstadoAFD>;
  public transicao: EstadoTransicao;
  public transicaoArray: Array<EstadoTransicao>;


  constructor(public navCtrl: NavController) {
    this.EstadoFinalIn = false;
    this.EstadoInicialIn = false;

    this.estadoArray = new Array<EstadoAFD>();
    this.transicaoArray = new Array<EstadoTransicao>();
    this.items = new Array<String>();
    this.itemsTrasicao = new Array<String>();
  }


  public validarCadeia() {
   var cadeia:string[] = this.cadeia.split(',');
   var transicao = new Transicao();
   var estadoInicial:EstadoAFD;
   var auxInicial = -1;
    this.estadoArray.filter(function (i, idx) {
      if (i.getEstadoInicial() == true) {
        auxInicial = idx;
      }
    });
    estadoInicial = this.estadoArray[auxInicial];
    //alert(estadoInicial.getNomeEstado());
    transicao.ordenarEstados(estadoInicial,this.transicaoArray,cadeia,0);
    if(transicao.estadoDestino.getEstadoFinal() == true){
      alert("Estado final "+transicao.estadoDestino.getNomeEstado()+" cadeia aceita");
    }
    
  }

  public valueEstadoAtual(key) {
    var estadoK: string[] = key.split(" ");
    var estadoK1 = estadoK[1];
    var auxid = -1;
    this.estadoArray.filter(function (i, idx) {
      if (i.getNomeEstado() == estadoK1)
        auxid = idx;
    });
    this.estadoAtualSelect = auxid;
    //alert(this.estadoAtualSelect);
  }

  public valueAlfabeto(key) {
    this.alfabetoSelectItem = key;
  }

  public valueEstadoDestino(key) {
    var estadoK: string[] = key.split(" ");
    var estadoK1 = estadoK[1];
    var auxid = -1;
    this.estadoArray.filter(function (i, idx) {
      if (i.getNomeEstado() == estadoK1)
        auxid = idx;
    });
    this.estadoDestinoSelect = auxid;
  }

  public delete(item: string) {

    var itemT: string[] = item.split(" ");
    //alert(itemT[1]);
    this.items = this.items.filter(i => i != item);
    for (var i = 0; i < this.estadoArray.length; i++) {
      if (this.estadoArray[i].getNomeEstado() === itemT[1]) {
        this.estadoArray.splice(i, 1);
      }
    }
  }

  public addTransicao() {

    this.transicao = new EstadoTransicao();
    this.transicao.setEstadoAtual(this.estadoArray[this.estadoAtualSelect]);
    this.transicao.setEstadoDestino(this.estadoArray[this.estadoDestinoSelect]);
    this.transicao.setAlfabeto(this.alfabetoSelectItem);
    this.transicaoArray.push(this.transicao);
    //alert(this.transicaoArray[0].getEstadoDestino().getNomeEstado());
    this.itemsTrasicao.push("{ " + this.transicao.getEstadoAtual().getNomeEstado() + ", " +
      this.transicao.getAlfabeto() + ", " + this.transicao.getEstadoDestino().getNomeEstado() + " }");

  }

  public addEstado() {
    this.estado = new EstadoAFD();
    this.estado.setNomeEstado(this.NomeEstadoIn);
    var alfabeto = this.AlfabetoIn.split(',');
    this.estado.setAlfabeto(alfabeto);
    this.estado.setEstadoInicial(this.EstadoInicialIn);
    this.estado.setEstadoFinal(this.EstadoFinalIn);
    //location.reload();

    var estadoText: string;

    if (this.estado.getEstadoInicial() == true && this.estado.getEstadoFinal() == false) {
      estadoText = ("{ " + this.estado.getNomeEstado() + " }" + " é um Estado Inicial");
    } else if (this.estado.getEstadoFinal() == true && this.estado.getEstadoInicial() == false) {
      estadoText = ("{ " + this.estado.getNomeEstado() + " }" + " é um Estado Final");
    } else if (this.estado.getEstadoInicial() == true && this.estado.getEstadoFinal() == true) {
      estadoText = ("{ " + this.estado.getNomeEstado() + " }" + " é um Estado Inicial e Final");
    } else {
      estadoText = ("{ " + this.estado.getNomeEstado() + " }");
    }
    this.items.push(estadoText);
    this.estadoArray.push(this.estado);

    this.NomeEstadoIn = "";
    this.EstadoFinalIn = false;
    this.EstadoInicialIn = false;
    this.alfabetoSelect = alfabeto;

  }


  public ViewEstado() {
    if (this.estadoArray[0].getNomeEstado()) {
      var nome: string = this.estadoArray[0].getNomeEstado();
      alert(nome);
    }
  }

}


// classe estado

class EstadoAFD {

  private alfabeto: string[];
  private nomeEstado: string;
  private estadoInicial: boolean;
  private estadoFinal: boolean;

  constructor() {

  }

  public setAlfabeto(alfabeto: string[]) {
    this.alfabeto = alfabeto;
  }
  public getAlfabeto(): string[] {
    return this.alfabeto;
  }

  public setNomeEstado(nomeEstado: string) {
    this.nomeEstado = nomeEstado;
  }
  public getNomeEstado(): string {
    return this.nomeEstado;
  }
  public setEstadoInicial(estadoInicial: boolean) {
    this.estadoInicial = estadoInicial;
  }
  public getEstadoInicial(): boolean {
    return this.estadoInicial;
  }
  public setEstadoFinal(estadoFinal: boolean) {
    this.estadoFinal = estadoFinal;
  }
  public getEstadoFinal(): boolean {
    return this.estadoFinal;
  }

}

/// classe transição

class EstadoTransicao {

  private estadoAtual: EstadoAFD;
  private estadoDestino: EstadoAFD;
  private alfabeto: string;

  constructor() {

  }

  public setEstadoAtual(estadoAtual: EstadoAFD) {
    this.estadoAtual = estadoAtual;
  }

  public getEstadoAtual(): EstadoAFD {
    return this.estadoAtual;
  }

  public setEstadoDestino(estadoDestino: EstadoAFD) {
    this.estadoDestino = estadoDestino;
  }

  public getEstadoDestino(): EstadoAFD {
    return this.estadoDestino;
  }
  public setAlfabeto(alfabeto: string) {
    this.alfabeto = alfabeto;
  }

  public getAlfabeto(): String {
    return this.alfabeto;
  }


}

class Transicao {

  public transicao: Array<EstadoTransicao>;
  public estadoDestino: EstadoAFD;

  constructor() {
    this.transicao = new Array<EstadoTransicao>();
    this.estadoDestino = new EstadoAFD;
  }

  public ordenarEstados(estado: EstadoAFD, transicao: Array<EstadoTransicao>, alf: string[], k: number) {

    if (k < alf.length) {

      for (var i = 0; i < transicao.length; i++) {
        if (transicao[i].getEstadoAtual() == estado) {
          this.transicao.push(transicao[i]);
        }
      }
      for (var j = 0; j < this.transicao.length; j++) {
        if (this.transicao[j].getAlfabeto() == alf[k]) {
          this.estadoDestino = this.transicao[j].getEstadoDestino();
        }
      }
      this.ordenarEstados(this.estadoDestino, transicao, alf, k + 1);
    }
  }


}


